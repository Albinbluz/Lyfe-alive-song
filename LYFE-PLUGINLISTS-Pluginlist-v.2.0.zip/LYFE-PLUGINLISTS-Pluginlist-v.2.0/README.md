[](https://cardivo.vercel.app/api?name=TOTAL_PLUGINS%20&description=𝐏𝐋𝐔𝐆𝐈𝐍𝐒𝐂𝐎𝐔𝐍𝐓=𝟱𝟬&image=https://i.imgur.com/2NoFYTg.jpeg?q=tbn:ANd9GcR7aMC3bf4bg4l_nhYS2Un9FXbFYcB4T83Shjk8xSUZDh_D61LFpzbpeqLW&s=10?v=4&backgroundColor=%23e4f2f6&instagram=headless__angels.exo&github=mask-sir&) 
   <br>
<h1 align="center"> LYFE001 PLUGIN LISTS </h1>
<div align="center">
  <!img align="center" alt="Coding" width="500" src="https://media2.giphy.com/media/oxjEQAAERDpRGp51D3/giphy.gif?cid=6c09b9526682283d53192f0e4f5ea1fc0b0caba1f016f472&rid=giphy.gif&ct=g"> <!br /> 
  <img border-radius: 30px src="https://i.imgur.com/dDcrb4k.jpeg" width="1000" height="300"/>

<br /> 
<p align="center"> <img src="https://komarev.com/ghpvc/?username=LYFE-PLUGINLISTS&label=Visitors%20count&color=10d9c3&style=plastic" alt="lyfe-plugin-list" /> </p>
<details>
<summary>🤔HOW TO INSTALL PLUGIN??</summary>
<p>

<h2 align="center">  ➠ ʜᴏᴡ ᴛᴏ ɪɴsᴛᴀʟʟ ᴘʟᴜɢɪɴ
</h1>
<!CODED BY MASK SER>

✯ <ʜᴀɴᴅʟᴇʀ> ᴘʟᴜɢɪɴ <ᴘʟᴜɢɪɴ ʟɪɴᴋ>
<h3 align="center">  ➠ ʜᴏᴡ ᴛᴏ ʀᴇᴍᴏᴠᴇ ᴘʟᴜɢɪɴ</h1>
 

✯ <ʜᴀɴᴅʟᴇʀ>ʀᴇᴍᴏᴠᴇ <ᴘʟᴜɢɪɴ ɴᴀᴍᴇ>
</p>
</details>

### FOR PLUGIN EDITING TUTORIAL CLICK BELOW
 <a href="https://youtu.be/9PgSQzQn5Qc"><img src="https://img.shields.io/badge/-watch%20video-critical?style=for-the-badge&logo=youtube&logoColor=white">
   <br>
 

ᴄʟɪᴄᴋ ᴡᴀ ʟᴏɢᴏ ᴛᴏ ᴊᴏɪɴ sᴜᴘᴘᴏʀᴛ ɢʀᴏᴜᴘ 👇 
<br> [![join](https://github.com/Alien-alfa/PublicBot/blob/main/wlogo.svg.png)](https://chat.whatsapp.com/Ezk6tfkqqDuKDlEsQR1lHA)
  <div align="center"
_____________________________
## WHATS NEW                 |
1)emix (20/03/2022)          |
_____________________________|      
<h4 align="center">➥ PLUGINS</h1>
__________________________________
___________________________________
<h3 align="center">LYFE00011 MD BOT PLUGINS </h1>
<a href="https://github.com/mask-sir/LYFE-PLUGINLISTS"><img src="https://img.shields.io/badge/TOTAL%20MD%20PLUGINS%20%3D-34-green">
<h4 align="center">  ᐉFIND  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/lyfe00011">LYFE</a>


```js
https://gist.github.com/lyfe00011/53c8dcc141fbff006ae6e216788ee290/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : FINDS THE SONG IN THE AUDIO OR VIDEO <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉTRUE  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/lyfe00011">LYFE</a>


```js
https://gist.github.com/mask-sir/934954b89ca086f80c48bca2645ea6e6/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : TRUECALLER SEARCH <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉGTHUB  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">MASK SER</a>


```js
https://gist.github.com/mask-sir/b2d7730b5c259fc5cf17438b3ca8e970/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : GATHER INFORMATION FROM GITHUB FOR THE GIVEN USERNAME <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉCDATE  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">MASK SER</a>


```js
https://gist.github.com/mask-sir/deeac83034bbc5daa127653c9761279d
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : MEASURE THE TIME GAP <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉLIVE  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">MASK SER</a>


```js
https://gist.github.com/mask-sir/a232babba5a1f5e6f92a2d67f863cd91
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : LIVE TIME <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉ TG </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/lyfe00011">LYFE</a>


```js
https://gist.github.com/lyfe00011/785b3adb2796cae7b12912bf2500b2cb/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : DOWNLOAD STICKER FROM TELEGRAM <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉ RVTXT</h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">MASK SER</a>


```js
https://gist.github.com/mask-sir/a9840a826e93c8f1c0dd051808e3a440
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : REVERSE THE TEXT<br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉ ANIMY </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">MASK SER</a>


```js
https://gist.github.com/mask-sir/824a55b1f0609ac8f2a4ada7e90d664c
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ :RANDOM ANIME IMAGE WITH QUOTE <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉ GQR </h1>

 CONVERTED BY :<a href="http://www.github.com/lyfe00011">MASK SER</a>


```js
https://gist.github.com/mask-sir/ac58caaa77c085655dcde155d7ed853b
```

ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : TEXT TO QR CODE<br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉ SLINK </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">MASK SER</a>


```js
https://gist.github.com/mask-sir/0a4317cc375e57941aec4376c3d65c60
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : SHORTING THE LINK <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉ SETSUDO,DELSUDO,GETSUDO </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/lyfe00011">LYFE</a>


```js
https://gist.github.com/lyfe00011/c9b86f8327ca781160fbad2f4d0fbd66
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : sets/dels/gets sudo without entering heroku <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉEMIX  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/lyfe000111">LYFE</a>


```js
https://gist.github.com/lyfe00011/03fc0de72c912bb0784cd225e0b20490
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ :MIXES EMOJIS <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />

<h4 align="center">  ᐉ DOC </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/lyfe00011">LYFE</a>


```js
https://gist.github.com/lyfe00011/a8f926710a28706679158887649ea145
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : CONVERTE MESSAGES INTO DOCUMENT WITH NAME <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉ PLAY </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/lyfe00011">LYFE</a>


```js
https://gist.github.com/lyfe00011/56dbb82d05ebcd3ea614274e3996b29d
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : DOWNLOAD SONG FROM YOUTUBE <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉ VV </h1>

 CONVERTED BY :<a href="http://www.github.com/mask-sir">MASK SER</a>


```js
https://gist.github.com/lyfe00011/e9595f37d80ad9ee6d61a11ecb820b8c
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : DOWNLOAD VIEW ONCE <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉ LYRICS </h1>

 CONVERTED BY:<a href="http://www.github.com/mask-sir">MASK SER</a>


```js
https://gist.github.com/mask-sir/6cf06b4fc7ef6c3bbe2ba8eb8df138b6/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : get lyrics <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsappbot-md
<br />
<br />
<h4 align="center">  ᐉTEXT  </h1>

 CONVERTED BY :<a href="http://www.github.com/mask-sir">MASK SER</a>


```js
https://gist.github.com/mask-sir/d8030c5129944cf6b1bcaa2c8564cef4/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : TEXT TO TEXT <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉ IG </h1>

 CONVERTED BY:<a href="http://www.github.com/lyfe00011">MASK SER</a>


```js
https://gist.github.com/lyfe00011/404b6ef1a4a4ab0ac14b58845213680a
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : INSTAGRAM PROFILE SEARCH <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉJEAN  </h1>

 CONVERTED BY:<a href="http://www.github.com/lyfe00011">MASK SER</a>


```js
https://gist.github.com/lyfe00011/04b7af2187c54b5971f7d9b402296585
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : LIKE ALEXA <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉ CALC </h1>

 CONVERTED BY :<a href="http://www.github.com/lyfe00011">MASK SER</a>


```js
https://gist.github.com/lyfe00011/e10e123e74777416db6ef4c2dbc6a98c
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : calculator <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉTIME  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/lyfe00011">LYFE</a>


```js
https://gist.github.com/lyfe00011/470c297040daef2c7453ba4807f60e1b
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : GETS TIME INFO<br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉ TEXTMAKER </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/lyfe00011">LYFE</a>


```js
https://gist.github.com/lyfe00011/120eee18e3c6b3c5b9a351120d9bf496
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ :MAKE TEXT EFFECT PHOTS <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉSDYNO  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/lyfe00011">LYFE</a>


```js
https://gist.github.com/lyfe00011/9a2bd716a32551dd5de14a5557f495fe/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : SCHEDULE DYNO <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
**Use by Given format** <br/>
Example
```js
.sdyno start 00 00 // .sdyno stop 00 00
```
<br />
<br />
<h4 align="center">  ᐉ CAPTION </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/lyfe00011">LYFE</a>


```js
https://gist.github.com/lyfe00011/2ae359efa147d295dca8c1d53f88d947/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : COPY OR ADD CAPTION IN IMAGE OR VIDEO <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉ GROUPJIDS </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/lyfe00011">LYFE</a>


```js
https://gist.github.com/lyfe00011/2ba742b9483c374cddcce9fb6382bb5f/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : GET ALL GROUP JIDS IN YOUR CHAT <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉATS(zmfor)  </h1>
 CONVERTED BY :<a href="http://www.github.com/alen-kenz">ALEN</a>


```js
https://gist.github.com/mask-sir/7f8fa479c8c362bc1b2f1c50792da251/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : MFORWARD WITH INSTGRAM LINK PREVIEW <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
**Use by Given format** <br/>
Example
```js
.Ats MASK SER;BY MASK SER; ZMFOR GOING TO RELEASE ;111111111111;4005127;www.instagram.com/reels/osnsj;https://i.imgur.com/3CQLj9K.jpeg;https://i.imgur.com/b08knMk.jpeg;120363041103519586@g.us
```
<br />
<br />
<h4 align="center">  ᐉVOICE CHANGER  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/lyfe00011">LYFE</a>


```js
https://gist.github.com/mask-sir/8184816cacab0116bb39f32b3ad9aaf7
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : AUDIO EDITOR <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
**Use by Given format** <br/>
Example
```js
.fast / .robot
```
<br />
<br />
<h4 align="center">  ᐉWAME  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">MASK SER</a>


```js
https://gist.github.com/Alien-alfa/d5e3bc953bcc6e1efaf8a9790a60724a/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : wame generator  <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />
<h4 align="center">  ᐉMFORWARD (with link preview) </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/mask-sir">MASK SER</a>


```js
https://gist.github.com/mask-sir/0ac8d675f903a8ad4e38d9640b477d64
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : FORWARD REPLIED MESSAGE<br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011 WHATSAPP-BOT-MD
<br />
<br />
<h3 align="center">  ᐉDELETE  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/lyfe00011">LYFE</a>


```js
https://gist.github.com/lyfe00011/b73535d503bed41f5324344883cf0030
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : DELETE ANY MESSAGE SENDED BY ANY TIME,BY USER OR BOT<br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011 WHATSAPP-BOT-MD
<br />
<br />
<h4 align="center">  ᐉGROUP JIDS </h1>
 
 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/insanebwoi">INSANEBWOI</a>


```js
https://gist.github.com/mask-sir/85c95652f85958d307297cd3f5912070
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : GET JIDS OF THE GROUP MEMBERS <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011 WHATSAPP-BOT-MD
<br />
<br />
<h4 align="center">  ᐉMEE </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/ALEN-KENZ">ALEN</a>


```js
https://gist.github.com/Alen-kenz/352e450d19dd8f0cf2ba6bc18752e5b4/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ :SELF MENTION<br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011 WHATSAPP-BOT-MD
<br />
<br />
<h4 align="center">  ᐉ YTL </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/lyfe00011"> LYFE</a>


```js
https://gist.github.com/mask-sir/1a7ff517accca3dc4d800f23506e93d8
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : YOUTUBE SEARCH WITH LIST <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011 WHATSAPP-BOT-MD
<br />
<br />

<h4 align="center">  ᐉHECK  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/fasilvkn">FASIL</a>


```js
https://gist.github.com/fasilvkn/181ed05d6c06f8ae4ade81434024369c/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : jst a prank plugin <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011-whatsapp-bot-md
<br />
<br />

<h3 align="center"> NON-MD PLUGINS <h1 l>
<a href="https://github.com/mask-sir/LYFE-PLUGINLISTS"><img src="https://img.shields.io/badge/TOTAL%20NON%20MD%20PLUGINS%20%3D-52-blue">

_________________________________________________
<h3 align="center"> EDITOR PLUGINS 👽🌈 <h1 />
<h4 align="center">  ᐉAUDIO  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/lyfe00011">LYFE</a>


```js
https://gist.github.com/lyfe00011/01bf9387d9fc937b2ac54bd682551b73
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : AUDIO EDITOR <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011
<br />
<br />
**Use by Given format** <br/>
Example
```js
.fast / .robot
```
<br />
<br />
<h4 align="center">  ᐉEMOJIMIX  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/lyfe00011">LYFE</a>


```js
https://gist.github.com/mask-sir/3663f4c788dd0ab1cb980a3d83edcdce/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ 
:MIX THE EMOJIS lyfe00011
<br />
<br />
**Use by Given format** <br/>
Example
```js
.emix 😳😩
```
<br />
<br />

<h4 align="center">  ᐉ SPACK </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/"></a>


```js
https://gist.githubusercontent.com/WAHID-BOT/860ea78cd0103f0d7c412804a50effad
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ 
: To create text photo logos <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011
<br />
<br />
**Use by Given format** <br/>
Example
```js
.ipack
```
<br />
<br />

<h4 align="center"> ᐉFancy ttp</h1>
 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="https://github.com/SPARK-SHADOW">SPARK-SHADOW</a> <br /> 

```js
https://gist.githubusercontent.com/SPARK-SHADOW/37dc98cfbcbb45fb790deda1194e20d0
```

ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : fancy ttp <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011 <br /> 

<br />

<h4 align="center"> ᐉTrollmaker v1</h1>
 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="https://github.com/insanebwoi">insanebwoi</a> <br />
ᴄʀᴇᴅɪᴛ ᴛᴏ :<a href="https://github.com/lyfe00011">lyfe00011</a> <br /> 

```js
https://gist.githubusercontent.com/insanebwoi/52bfee77544a45cd493f108dbef9977b/raw
```

ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ :This plugin help you to make trolls include cat,dog trolls<br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011 <br /> 
<br />
<h4 align="center"> ᐉT-MAKE</h1>
 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="https://github.com/insanebwoi">insanebwoi</a> <br /> 

```js
https://gist.github.com/insanebwoi/5284ef05dee6dbb38d893c34bbf88fee
```

ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : This plugin help you to create custamaisable trolls by your choise by url<br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011 <br /> 
<br />


# 🎮GAMES
### ᐉSTONE PAPER SCISSORS 
 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/NJANRAZ">RAZ</a>

```js
https://gist.github.com/NJANRAZ/df82bdf4aca5e44def1bba7f778db188
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ :stone paper scissors game <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011
<br />
<br />
 ### ᐉ  slot

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/">DENIS</a>


```js
https://gist.githubusercontent.com/Whatsden/ff487de5452ef633fee2cf2e8595d7cd/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ :play a game<b/>
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011
<br />
<br />
<h3 align="center" > FORWARD PLUGINS ➡️ <h1 />
<h4 align="center" > FIRST WATCH THIS VIDEO AND USE MFORWRD PLUGINS </h1> 
 <a href="https://youtu.be/9PgSQzQn5Qc"><img src="https://img.shields.io/badge/-watch%20video-critical?style=for-the-badge&logo=youtube&logoColor=white">
   <br>

<h4 align="center">  ᐉsend plugin </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="https://github.com/farhan-dqz">farhan-dqz</a>


```js
https://gist.githubusercontent.com/farhan-dqz/67ba8fed33aa4f36083cf94788aed31d/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : Basic version of forward <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011
<br />
<br />

<h4 align="center">  ᐉ m-forward with fake preview status (.mforward) </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="https://github.com/lyfe00011">lyfe00011</a>

```js
https://gist.github.com/lyfe00011/467a2e45f4e36b8bb4782ee8da573ca0
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : improved version of forward.You can add any link in the body section (group link, YouTube,wame link etc...)<br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011 <br /> 

⊡ Need edit this plugin for make customasable 
<br />
<br />


<h4 align="center">  ᐉ m-forward custamaisable verify tick status (.cmfor)  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="https://github.com/insanebwoi">insanebwoi</a>

```js
https://gist.github.com/insanebwoi/a256b2751ad6298b5374eb40f9f62758
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : Custamaisable version of m forward <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011 <br /> 

⊡ No Need edit this plugin on github   <br/>
• you can even customize all things in this plugin eg url,caption,duration etc <br/>
**Use by Given format** <br/>
```js
Example .cmfor caption;99;https://i.imgur.com/BiLC1Ik.jpeg;jid1 jid2 jid3 jid4 ...
```
<br />
<br />




<h4 align="center">  ᐉ m-forward media preview with fully custamaisable (.zmfor) </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="https://github.com/insanebwoi">insanebwoi</a>

```js
https://gist.github.com/insanebwoi/3d3f705f5b9e6f38e0de47745530a312
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : Custamaisable version of m forward with media preview <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011 <br /> 

⊡ No Need edit this plugin on github  <br/>
• you can even customize all things in this plugin eg url,caption,head,body,duration,price,url,url2 etc <br/>
**Use by Given format** <br/>
Example 

```js
.zmfor ᴇxᴀᴍᴩʟᴇ ꜰᴏʀ ᴢᴍꜰᴏʀ;ᴍꜰᴏʀᴡᴀʀᴅ ᴍᴇᴅɪᴀ ᴩʀᴇᴠɪᴇᴡ ᴡɪᴛʜ ᴄᴜꜱᴛᴀᴍᴀɪꜱᴀʙʟᴇ ᴀᴅᴇᴅᴅ ᴛᴏ ᴩʟᴜɢɪɴ ʟɪꜱᴛ✔️;ᴩʟᴇᴀꜱᴇ ɢᴏ ᴀɴᴅ ᴄʜᴇᴄᴋ🔛;100;2022000;https://www.instagram.com/tv/CX8_LOXByX3/?utm_medium=copy_link;https://i.imgur.com/uLIOJBs.jpeg;https://i.imgur.com/F7KxLWv.jpeg;0@s.whatsapp.net
```

NB : PRICE TAG MUST ABOVE 100000 = ₹100.00 <br/>
     DURATION 100 = 1:40 sec 
<br />
<br />







<h4 align="center">  ᐉm-forward random custamaisable duration & title verify tick status </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="https://github.com/insanebwoi">insanebwoi</a>

```js
https://gist.github.com/insanebwoi/d7173ff5f8137e8bfc7d97ff61c41d49
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : Custamaisable version of m forward <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011 <br /> 

⊡ Your choice on editing or not this plugin youcan custamaise it by changing url in the programme <br/>
• you can even edit all things in this plugin exclude url  <br/>
**Use by Given format** <br/>
Example
```js
.crfor example;99;jid1 jid2 jid3 jid4 ...
```
<br />
<br />

<h3 align="center" >PRANK & FAKE PLUGINS👻 <h1 />
<h4 align="center"> ᐉ Scam typing&recording </h1>
 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="https://github.com/SPARK-SHADOW">SPARK-SHADOW</a> <br /> 

```js
https://gist.githubusercontent.com/SPARK-SHADOW/aa3991992fae718edb75b380336aff24
```

ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : This plugin make scam typing, recording voice to prank others <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011 <br />
.stop scam   to stop this in 20 sec <br />

<h4 align="center">  ᐉHACK </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/SPARK-SHADOW">SHADOW</a>


```js
https://gist.githubusercontent.com/SPARK-SHADOW/14d9be053f21192f31e79baaf96c2852/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ:Fake hack plugin for just prank <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011
<br />
<br />
<h4 align="center">  ᐉCHERRYHECK  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/insanebwoi">INSANEBOY</a>


```js
https://gist.github.com/mask-sir/a2f9ad2b1735f154f5e38796c1535ac6
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴɪɴ:Fake hack plugin for just prank <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011
<br />
<br />
<h4 align="center">  ᐉ TRUE </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://github.com/shefinkl14">SHEFIN</a>


```js
https://gist.github.com/mask-sir/84df6b7066370735304e63f9db66379f
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪ
 : Fake Truecaller plugin (og not released)<br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011
<br />
<br />
<h3 align="center" > WHATSAPP REALTED PLUGINS🪀 <h1 />
<h4 align="center">  ᐉTRUECALLER😍  </h1>
 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/Souravkl11">SOURAV</a>


```js
https://gist.github.com/souravkl11/156a01ae93836f3c13c48b92c6d074af
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : SEARCH IN TRUECALLER <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011
<br />
<br />
<h5 align="center">  ᐉCLR </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/LoveYou0011">ELDRIN</a>


```js
https://gist.githubusercontent.com/LoveYou0011/ffe47541370a862894403847f0fcb90b/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : CLEAR CHAT  <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011
<br />
<br />

<h4 align="center">  ᐉ CAPTION </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/lyfe00011">LYFE</a>


```js
https://gist.github.com/lyfe00011/581702e4bb93186c7730cbc18dfe1d98/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : ADD OR GET THE CAPTIONS OF IMAGES OR VIDEOS <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011
<br />
<br />

<h4 align="center"> ᐉAnti view once </h1>
 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="https://github.com/lyfe00011">lyfe00011</a>

```js
https://gist.githubusercontent.com/lyfe00011/582ff0b2f2e61cc0cf4ea48084d52cb0/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : This plugin help you to convert view once media to normal media by camand <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011 <br />

<h4 align="center">  ᐉ GPJIDS </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/insanebwoi">INSANE BOY</a>


```js
https://gist.github.com/mask-sir/d273d9b05f938a6cf1181c4f213a67c8/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ 
:  To get full member jids.you can ut for pmbc, audiobc, broadcast to all<br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011
<br />
<br />
<h4 align="center">  ᐉ MEE</h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/lyfe00011">LYFE</a>


```js
https://gist.github.com/lyfe00011/5e088a997da3d81dbd1f2cca57ac4bca/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪ:self MENTION<br
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011
<br />
<br />


<h4 align="center">  ᐉ PM  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/"></a>


```js
https://gist.githubusercontent.com/mask-sir/4f062aa3e3adca278e1805f09af2935a/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : SEND THE OWNER VCARD<br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011
<br />
<br />


<h4 align="center">  ᐉ YOU </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/iam-arya">ARYA</a>


```js
https://gist.github.com/mask-sir/c61b8efb686d7cbc077d7ebdd84a4ec6
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : mention the replied person lyfe00011
<br />
<br />

<h align="center">  ᐉ IM </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/SPARK-SHADOW">SHADOW</a>


```js
https://gist.github.com/mask-sir/af610e4911906459866d026b773bfb02
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : ADD NOTEPAD OR DETAILS (EDIT AND USE)<br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011
<br />
<br />
<h4 align="center">  ᐉ Dlt </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/insanebwoi">INSANE BOY</a>


```js
https://gist.github.com/insanebwoi/baedffadfc3c492399e120f
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : DELETE THE MESSAGE SEND BY THE BOT (NO TIME LIMIT,NOT DELETE MSG SENDED BY THE USER <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011
<br />
<br />
<h align="center">  ᐉ STATUS SAVER </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/"></a>


```js
https://gist.githubusercontent.com/mask-sir/80f32efa9208e4194fd281f9ef9b8b54/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ :save the status  <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011
<br />
<br />
**Use by Given format** <br/>
Example
```js
.#
```
<br />
<br />



<h4 align="center">  ᐉLIST ONLINE  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/lyfe00011">LYFE</a>


```js
https://gist.github.com/mask-sir/1bf6af13bed8e780033836d5ba665547/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011
<br />
<br />
<h4 align="center">  ᐉRENAME, SETDESC,GPP </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/SPARK-SHADOW">SHADOW</a>


```js
https://gist.github.com/mask-sir/cafa4bf05c7fa66a93a159872a511dd1
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ 
:To change group name/desc/dp<br /> 
``` js
https://gist.github.com/fasilvkn/69105233899e9d033fcc7a27bee9c1e1/raw
```
For changing group profile
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011
<br />
<br />
<h3 align="center"> OTHER USEFULL PLUGINS😻 <h1 />
<h4 align="center">  ᐉANIMY  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/NJANRAZ">RAZ</a>


```js
https://gist.github.com/mask-sir/d6ef3531d9162a08657103f341609f35/raw

```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : RANDOM ANIME PHOTO <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011
<br />
<br />
### ᐉ BUTTON 

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/lyfe00011">LYFE</a>


```js
https://gist.github.com/lyfe00011/1df704a43dc82513679020d701b63767/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ :MAKE BUTTON MESSAGE <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011
<br />
<br />
**Use by Given format** <br/>
Example
```js
.Button HELLLO,©MASK,TEST,DONE
```
<br />
<br />
<h3 align="center">  ᐉ CALC </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/lyfe00011">LYFE</a>


```js
https://gist.github.com/mask-sir/68fc7fbd4b007dfcb8c3f3e293ea2934/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : TO CALCULATE <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011
<br />
<br />
**Use by Given format** <br/>
Example
```js
.calc 1+1 / 1*1 /1-1 / (1/1)
```
<br />
<br />
<h4 align="center"> ᐉ Cropped Sticker</h1>
 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="https://github.com/SPARK-SHADOW">SPARK-SHADOW</a>



```js
https://gist.githubusercontent.com/SPARK-SHADOW/7a03decfda97e6da7606880d9db85456/raw
```

ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ :This plugin help you to make sticker by croping in ratio 1:1<br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011 <br /> 
<br />

<h4 align="center"> ᐉFancy menu v3 (updated)  </h1>
 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="https://github.com/SPARK-SHADOW">SPARK-SHADOW</a> <br /> 

```js
https://gist.github.com/SPARK-SHADOW/2633547513e2fa88e9af5296961598b2
```

ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : Modified version of menu with time and date <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011 <br />

### ᐉ Setsudo,delsudo,getsudo 

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/lyfe00011">LYFE</a>


```js
https://gist.github.com/lyfe00011/9aa68a52481c439fd6aee2958a7833a3/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪn :set/delete/get sudo without typing var cmnd: <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011
<br />
<br />
**Use by Given format** <br/>
Example
```js
.setsudo <nbr>/ replay or mention to a person (.setsudo @.....)
```
<br />
<br />

###  ᐉ IG  </h1>
 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="www.github.com/lyfe00011">LYFE</a>

```js
https://gist.github.com/lyfe00011/83a379a3aa375249962e49a734df8bbf/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : SEARCH THE USERNAME ON INSTAGRAM AND GETS THE PROFILE DETAILS <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011
<br />
<br />
**Use by Given format** <br/>
Example
```js
.Ig <username>
```
<br />
<br />
<h5 align="center"> ᐉ Text  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/lyfe00011">LYFE</a>


```js
https://gist.github.com/lyfe00011/0cdaab914811d3e88f2357e7cd1deac2/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ :MAKE FONTS WITH DOTED LINES <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011
<br />
<br />



### ᐉ WAME[with green tick and name]</h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="www.github.com/mask-sir">MASK SER</a>


```js
https://gist.github.com/mask-sir/e6f02413f74453ad0ae31c5b7d965d7b/raw
```
### without green tick (fast sending)
```js
https://gist.github.com/mask-sir/a0d16d6ea93d6ce1c6b5e0c7ab52da7e
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : Gets the invite link of the replied person <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011
<br />
<br />

<h4 align="center"> ᐉSub title</h1>
 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="https://github.com/lyfe00011">lyfe00011</a>

```js
https://gist.github.com/lyfe00011/ef753048e046495b7fdb04747299b834
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : This plugin gev you Subtitle <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011 <br /> 

<h4 align="center"> ᐉLive time</h1>
 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="https://github.com/insanebwoi">insanebwoi</a> <br /> 
ᴄʀᴇᴅɪᴛ ᴛᴏ :<a href="https://github.com/SPARK-SHADOW">SPARK-SHADOW</a> <br /> 

```js
https://gist.githubusercontent.com/insanebwoi/fb0f9f34e0b36c3b3adc0a3bda2bb8c0/raw
```

ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : You can know which time it is by this plugin <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011 <br /> 
<br />


<h4 align="center"> ᐉ Custamaisable list </h1>
 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="https://gist.github.com/Whatsden">Whatsden</a> <br /> 

```js
https://gist.github.com/Whatsden/02858adcf132ceac66b847d232ba08f8
```

ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : This plugin help to create list esly by geven example <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011 <br />
Example geven below
```js
.buttlist Message,click here,heading,list1,list2,list3
``` 
<h4 align="center"> ᐉNUM </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/lyfe00011">LYFE</a>


```js
https://gist.githubusercontent.com/lyfe00011/6b824f6957d9ac97d7b348ff376e2ace/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : FILTER THE CONTRY NUMBERS<br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011
<br />
<br />
<h4 align="center">  ᐉ KIK </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/lyfe00011">LYFE</a>


```js
https://gist.githubusercontent.com/sweetscherry/701f7181f8b4e93aa3955dfe47bce9db/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : removes the person with all matching numbers lyfe00011
<br />
<br />
**Use by Given format** <br/>
Example
```js
.kik 91
```
<br />
<br />
<h4 align="center">  ᐉ PLAY </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/lyfe00011">LYFE</a>


```js
https://gist.github.com/lyfe00011/ffc1d10b63154bc3870717d2ab7ffcf0/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : Download the song from YouTube<br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011
<br />
<br />
**Use by Given format** <br/>
Example
```js
.play beliver
```
<br />
<br />
<h4 align="center">  ᐉ GQR </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/">LYFE</a>


```js
https://gist.githubusercontent.com/lyfe00011/9f07e4048e95824c886c14c2550f90bc/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪ : make the qr code of Given text <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011
<br />
<br />
<h align="center">  ᐉ DOC </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/lyfe00011">LYFE</a>


```js
https://gist.githubusercontent.com/lyfe00011/ca1d9edf4ae2af7ad08f079f10da4d22/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : convert the reolied message to document<br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011
<br />
<br />
<h4 align="center">  ᐉ TLINK</h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/lyfe00011">LYFE</a>


```js
https://gist.github.com/mask-sir/e6ead0c956dc853ba3c7db1c87b006d9/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : Covert the replied message to link <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ :lyfe00011
<br />
<br />
<h4 align="center"> jean ᐉ  </h1>

 ᴄʀᴇᴀᴛᴇᴅ ʙʏ :<a href="http://www.github.com/lyfe00011">LYFE</a>


```js
https://gist.githubusercontent.com/lyfe00011/4d5c4b2a71930b66e829182f632ab9c8/raw
```
ᴜsᴀɢᴇ ᴏғ ᴛʜɪs ᴘʟᴜɢɪɴ : search the querry <br /> 
sᴜᴘᴘᴏʀᴛɪɴɢ ᴠᴇʀsɪᴏɴ : lyfe00011
<br />
<br />
**Use by Given format** <br/>
Example
```js
.jean question
```
<br />
<br />

__________________________________
__________________________________

## ▣ Need to add your plugin here?
## [![Typing SVG align="center"](https://readme-typing-svg.herokuapp.com?font=Staatliches&color=0A0089&size=20&width=350&lines=We+know+there+are+a+lot+of+plugin;didnt+include+here+...;If+you+created+a+use+full+plugin;and+didnt+here+???;Contact+us+to+add+here+🙂;After+checking+the+use+and+scan;We+given+a+whatsapp+link+above;join+there+and+contact+us;If+there+is+a+problem+in+any+plugin;there+please+contact+us+......)](https://git.io/typing-svg) <br/>
<br/>

## ✆ Contact us 
<details>
<summary>🎈INFO</summary>
<p>

[ᴄᴏᴘɪᴇᴅ ғʀᴏᴍ <a href="http://github.com/insanebwoi/lyfe-plugins-list">ɪɴsᴀɴʙᴡᴏɪ <a/> ]<br />
ᴄᴀɴ ʏᴏᴜ ɢɪᴠᴇ ᴍᴇ ᴀ sᴛᴀʀ ✫  ☻ <br /> <br />

#### ᴄᴏɴᴅʀɪʙᴜᴛᴇ ᴛᴏ ❁ <br />
『 ʟʏғᴇ sᴇʀ 』 <br />
『 ᴍᴀsᴋ sᴇʀ』 <br />
『 ɪɴsᴀɴᴇʙᴡᴏɪ 』 <br />

</p>
</details>
<br />

### ᴛʜɪs ʙʟᴏɢɢᴇʀ ᴄʀᴇᴀᴛᴇᴅ ʙʏ ✎<br />
◨ ᴍᴀsᴋ sᴇʀ◧ <br />

 ©Lyfe 00011 USER BOT
